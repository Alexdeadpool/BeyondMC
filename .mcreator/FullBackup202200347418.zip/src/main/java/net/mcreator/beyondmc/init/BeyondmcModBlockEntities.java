
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.beyondmc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.beyondmc.block.entity.Coke3BlockEntity;
import net.mcreator.beyondmc.block.entity.Coke2BlockEntity;
import net.mcreator.beyondmc.block.entity.Coke0BlockEntity;
import net.mcreator.beyondmc.BeyondmcMod;

public class BeyondmcModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES,
			BeyondmcMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> COKE_0 = register("coke_0", BeyondmcModBlocks.COKE_0, Coke0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COKE_2 = register("coke_2", BeyondmcModBlocks.COKE_2, Coke2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COKE_3 = register("coke_3", BeyondmcModBlocks.COKE_3, Coke3BlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block,
			BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
