
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.beyondmc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.beyondmc.item.SusknifeItem;
import net.mcreator.beyondmc.item.PrismarinegauntletItem;
import net.mcreator.beyondmc.item.PistolItem;
import net.mcreator.beyondmc.item.KatanaItem;
import net.mcreator.beyondmc.item.HomedepotItem;
import net.mcreator.beyondmc.item.EssenceItem;
import net.mcreator.beyondmc.BeyondmcMod;

public class BeyondmcModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BeyondmcMod.MODID);
	public static final RegistryObject<Item> AMONGUS = REGISTRY.register("amongus_spawn_egg",
			() -> new ForgeSpawnEggItem(BeyondmcModEntities.AMONGUS, -3407872, -16724788, new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND)));
	public static final RegistryObject<Item> GREMLIN = REGISTRY.register("gremlin_spawn_egg",
			() -> new ForgeSpawnEggItem(BeyondmcModEntities.GREMLIN, -16711852, -10210284, new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND)));
	public static final RegistryObject<Item> PRISMARINEGAUNTLET = REGISTRY.register("prismarinegauntlet", () -> new PrismarinegauntletItem());
	public static final RegistryObject<Item> KATANA = REGISTRY.register("katana", () -> new KatanaItem());
	public static final RegistryObject<Item> PISTOL = REGISTRY.register("pistol", () -> new PistolItem());
	public static final RegistryObject<Item> CORE = block(BeyondmcModBlocks.CORE, BeyondmcModTabs.TAB_BEYOND);
	public static final RegistryObject<Item> SUSKNIFE = REGISTRY.register("susknife", () -> new SusknifeItem());
	public static final RegistryObject<Item> ESSENCE = REGISTRY.register("essence", () -> new EssenceItem());
	public static final RegistryObject<Item> HOMEDEPOT = REGISTRY.register("homedepot", () -> new HomedepotItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
