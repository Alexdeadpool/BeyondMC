
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.beyondmc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.beyondmc.BeyondmcMod;

public class BeyondmcModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, BeyondmcMod.MODID);
	public static final RegistryObject<SoundEvent> AMONGUS_ATTACK = REGISTRY.register("amongus_attack",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "amongus_attack")));
	public static final RegistryObject<SoundEvent> AMONGUS_DEATH = REGISTRY.register("amongus_death",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "amongus_death")));
	public static final RegistryObject<SoundEvent> AMONGUS_PASSIVE = REGISTRY.register("amongus_passive",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "amongus_passive")));
	public static final RegistryObject<SoundEvent> AMONGWALK = REGISTRY.register("amongwalk",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "amongwalk")));
	public static final RegistryObject<SoundEvent> ANKLES = REGISTRY.register("ankles",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "ankles")));
	public static final RegistryObject<SoundEvent> GAUNTLET2 = REGISTRY.register("gauntlet2",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "gauntlet2")));
	public static final RegistryObject<SoundEvent> GAUNTLETSOUND = REGISTRY.register("gauntletsound",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "gauntletsound")));
	public static final RegistryObject<SoundEvent> GREMLINDEATH = REGISTRY.register("gremlindeath",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "gremlindeath")));
	public static final RegistryObject<SoundEvent> GREMLINFOOTSTEPS = REGISTRY.register("gremlinfootsteps",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "gremlinfootsteps")));
	public static final RegistryObject<SoundEvent> GREMLINOUCH = REGISTRY.register("gremlinouch",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "gremlinouch")));
	public static final RegistryObject<SoundEvent> HOMEDEOPT = REGISTRY.register("homedeopt",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "homedeopt")));
	public static final RegistryObject<SoundEvent> PASSIVEGREMLIN = REGISTRY.register("passivegremlin",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "passivegremlin")));
	public static final RegistryObject<SoundEvent> PISTOLSOUND = REGISTRY.register("pistolsound",
			() -> new SoundEvent(new ResourceLocation("beyondmc", "pistolsound")));
}
