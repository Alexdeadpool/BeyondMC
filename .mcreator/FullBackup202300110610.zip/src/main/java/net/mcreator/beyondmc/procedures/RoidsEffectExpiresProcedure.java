package net.mcreator.beyondmc.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class RoidsEffectExpiresProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if(entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.HARM,100,1, false, false));
}
}
