

package net.mcreator.beyondmc.client.renderer;




public class AlexdeadpoolRenderer extends HumanoidMobRenderer<AlexdeadpoolEntity, HumanoidModel<AlexdeadpoolEntity>> {

	public AlexdeadpoolRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);

		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
				new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));

	}


	@Override public ResourceLocation getTextureLocation(AlexdeadpoolEntity entity) {
		return new ResourceLocation("beyondmc:textures/entities/alexdeadpool_original.png");
	}



}
