

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class SilveringotItem extends Item {

	public SilveringotItem() {
		super(new Item.Properties()
				.tab(BeyondmcModTabs.TAB_BEYOND)
				.stacksTo(64)
				.rarity(Rarity.COMMON)
		);
	}



















}
