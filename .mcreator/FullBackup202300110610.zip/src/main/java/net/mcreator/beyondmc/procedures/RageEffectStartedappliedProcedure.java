package net.mcreator.beyondmc.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class RageEffectStartedappliedProcedure {
public static void execute(
LevelAccessor world,
double x,
double y,
double z,
Entity entity
) {
if(
entity == null
) return ;
RageOnEffectActiveTickProcedure.execute(world,x,y,z)
;
if(entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,1000,1, false, false));if(entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED,1000,1, false, false));if(entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,1000,1, false, false));BeyondmcMod.queueServerWork(1000, () -> {
RageEffectExpiresProcedure.execute(entity)
;
});
}
}
