

package net.mcreator.beyondmc.item;

import net.minecraft.network.chat.Component;

public class PrismarinecolossusItem extends RecordItem {

	public PrismarinecolossusItem() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("beyondmc:prismarinecolossus")),
				new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND).stacksTo(1).rarity(Rarity.RARE), 1000);
	}









}
