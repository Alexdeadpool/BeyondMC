package net.mcreator.beyondmc.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class SuspiciouspowderRightclickedOnBlockProcedure {
public static void execute(
LevelAccessor world,
double x,
double y,
double z,
Entity entity,
ItemStack itemstack
) {
if(
entity == null
) return ;
ItemStack seeds = ItemStack.EMPTY;BlockState stage0 = Blocks.AIR.defaultBlockState();
seeds = new ItemStack(BeyondmcModItems.SUSPICIOUSPOWDER.get()); stage0 = BeyondmcModBlocks.COKE_0.get().defaultBlockState();if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem():ItemStack.EMPTY).getItem() == seeds.getItem()&&(world.getBlockState(new BlockPos(x,y,z))).is(BlockTags.create(new ResourceLocation("minecraft:farmland")))&&(world.getBlockState(new BlockPos(x,y+1,z))).getMaterial() == net.minecraft.world.level.material.Material.AIR&&stage0.canSurvive(world, new BlockPos(x,y+1,z))) {world.setBlock(new BlockPos(x,y+1,z), stage0,3);
if (!(new Object(){
public boolean checkGamemode(Entity _ent){
if(_ent instanceof ServerPlayer _serverPlayer) {
return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
} else if(_ent.level.isClientSide() && _ent instanceof Player _player) {
return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null
&& Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
}
return false;
}
}.checkGamemode(entity))) {if (entity instanceof LivingEntity _entity) {
ItemStack _setstack = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem():ItemStack.EMPTY);
_setstack.setCount((int)((itemstack).getCount()-1));
_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
if (_entity instanceof Player _player) _player.getInventory().setChanged();
}}}
}
}
