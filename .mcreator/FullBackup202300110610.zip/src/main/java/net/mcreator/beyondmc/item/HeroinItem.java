

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class HeroinItem extends Item {

	public HeroinItem() {
		super(new Item.Properties()
				.tab(BeyondmcModTabs.TAB_BEYOND)
				.stacksTo(64)
				.rarity(Rarity.UNCOMMON)
		);
	}









	@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("You will need a needle"));
	}










}
