

package net.mcreator.beyondmc.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class SuspiciouslogBlock extends
Block
{
public SuspiciouslogBlock() {
super(
BlockBehaviour.Properties.of(Material.WOOD)
.sound(SoundType.WOOD)
.strength(1f, 10f)
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
}