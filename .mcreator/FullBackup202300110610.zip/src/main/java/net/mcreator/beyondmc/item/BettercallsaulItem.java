

package net.mcreator.beyondmc.item;

import net.minecraft.network.chat.Component;

public class BettercallsaulItem extends RecordItem {

	public BettercallsaulItem() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("beyondmc:bettercallsaul")),
				new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND).stacksTo(1).rarity(Rarity.RARE), 1000);
	}

	@Override @OnlyIn(Dist.CLIENT) public boolean isFoil(ItemStack itemstack) {
		return true;
	}








}
