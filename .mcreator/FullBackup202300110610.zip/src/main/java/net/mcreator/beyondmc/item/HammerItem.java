

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;

public class HammerItem extends AxeItem {
public HammerItem () {
super( new Tier() {
public int getUses() {
return 100;
}
public float getSpeed() {
return 4f;
}
public float getAttackDamageBonus() {
return 2f;
}
public int getLevel() {
return 2;
}
public int getEnchantmentValue() {
return 2;
}
public Ingredient getRepairIngredient() {
return Ingredient.of(new ItemStack(Items.IRON_INGOT));
}
},
1,-3f,
new Item.Properties()
.tab(BeyondmcModTabs.TAB_BEYOND)
);
}
}
