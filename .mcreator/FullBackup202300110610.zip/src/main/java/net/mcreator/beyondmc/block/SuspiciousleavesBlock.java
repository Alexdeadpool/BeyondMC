

package net.mcreator.beyondmc.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class SuspiciousleavesBlock extends
LeavesBlock
{
public SuspiciousleavesBlock() {
super(
BlockBehaviour.Properties.of(Material.LEAVES)
.sound(SoundType.GRASS)
.strength(0.2f, 1f)
.lightLevel(s -> 1)
.noOcclusion()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 1;
}
@Override public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
return 1;
}
}