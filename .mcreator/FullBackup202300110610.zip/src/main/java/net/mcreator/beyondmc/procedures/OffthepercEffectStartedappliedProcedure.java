package net.mcreator.beyondmc.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class OffthepercEffectStartedappliedProcedure {
public static void execute(
LevelAccessor world,
Entity entity
) {
if(
entity == null
) return ;
if(entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,1000,5, false, false));BeyondmcMod.queueServerWork(1000, () -> {
OffthepercEffectExpiresProcedure.execute(entity)
;
});
}
}
