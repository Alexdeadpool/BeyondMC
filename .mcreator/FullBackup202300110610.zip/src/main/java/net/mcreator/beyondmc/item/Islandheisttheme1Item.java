

package net.mcreator.beyondmc.item;

import net.minecraft.network.chat.Component;

public class Islandheisttheme1Item extends RecordItem {

	public Islandheisttheme1Item() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("beyondmc:islandheist1")),
				new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND).stacksTo(1).rarity(Rarity.RARE), 1000);
	}


	@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("By SORA"));
	}







}
