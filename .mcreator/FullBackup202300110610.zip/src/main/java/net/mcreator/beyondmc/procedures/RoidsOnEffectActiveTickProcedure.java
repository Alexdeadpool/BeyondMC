package net.mcreator.beyondmc.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class RoidsOnEffectActiveTickProcedure {
public static void execute(
LevelAccessor world,
double x,
double y,
double z
) {
if (world instanceof ServerLevel _level)
_level.sendParticles((SimpleParticleType) (BeyondmcModParticleTypes.ROIDPARTICLE.get()), x, y, z, 5, 3, 3, 3, 1);
}
}
