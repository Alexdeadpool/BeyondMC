

package net.mcreator.beyondmc.item;

import net.minecraft.network.chat.Component;

public class HomedepotItem extends RecordItem {

	public HomedepotItem() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("beyondmc:homedeopt")),
				new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND).stacksTo(1).rarity(Rarity.RARE), 1000);
	}









}
