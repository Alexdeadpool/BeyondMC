

package net.mcreator.beyondmc.item;

import net.minecraft.network.chat.Component;

public class StayoutofmyterritoryItem extends RecordItem {

	public StayoutofmyterritoryItem() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("beyondmc:stayoutofmyterritory")),
				new Item.Properties().tab(BeyondmcModTabs.TAB_BEYOND).stacksTo(1).rarity(Rarity.RARE), 1000);
	}

	@Override @OnlyIn(Dist.CLIENT) public boolean isFoil(ItemStack itemstack) {
		return true;
	}








}
