

package net.mcreator.beyondmc.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class CyanredstonelampBlock extends
Block
{
public CyanredstonelampBlock() {
super(
BlockBehaviour.Properties.of(Material.DIRT)
.sound(SoundType.GLASS)
.strength(1f, 10f)
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
List<ItemStack> dropsOriginal = super.getDrops(state, builder);
if(!dropsOriginal.isEmpty())
return dropsOriginal;
return Collections.singletonList(new ItemStack(this, 1));
}
@Override public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, BlockPos fromPos, boolean moving) {
super.neighborChanged(blockstate, world, pos, neighborBlock, fromPos, moving);
if (world.getBestNeighborSignal(pos) > 0) {
CyanredstonelampRedstoneOnProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ()
);
}
}
}