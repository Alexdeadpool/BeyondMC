

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class DollarItem extends Item {

	public DollarItem() {
		super(new Item.Properties()
				.tab(BeyondmcModTabs.TAB_BEYOND)
				.stacksTo(64)
				.rarity(Rarity.RARE)
		);
	}









	@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("Worth roughly 1 gold and two paper"));
	}










}
