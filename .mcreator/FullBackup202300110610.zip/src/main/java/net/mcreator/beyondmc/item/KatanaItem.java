

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;

public class KatanaItem extends SwordItem {
public KatanaItem () {
super( new Tier() {
public int getUses() {
return 100;
}
public float getSpeed() {
return 4f;
}
public float getAttackDamageBonus() {
return 0f;
}
public int getLevel() {
return 1;
}
public int getEnchantmentValue() {
return 2;
}
public Ingredient getRepairIngredient() {
return Ingredient.of(new ItemStack(Blocks.IRON_BARS));
}
},
3,1f,
new Item.Properties()
.tab(BeyondmcModTabs.TAB_BEYOND)
);
}
@Override public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
KatanaRightclickedProcedure.execute(
entity,ar.getObject()
);
return ar;
}
@Override public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
super.inventoryTick(itemstack, world, entity, slot, selected);
if (selected)
KatanaToolInHandTickProcedure.execute(
entity
);
}
}
