

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class WeedItem extends Item {

	public WeedItem() {
		super(new Item.Properties()
				.tab(BeyondmcModTabs.TAB_BEYOND)
				.stacksTo(64)
				.rarity(Rarity.UNCOMMON)
				.food((new FoodProperties.Builder())
					.nutrition(0)
					.saturationMod(0f)
					
					
					.build())
		);
	}











		@Override public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
			ItemStack retval =
			super.finishUsingItem(itemstack, world, entity);

				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
    

    RelaxationEffectStartedappliedProcedure.execute(world,x,y,z,entity)
;

				return retval;
		}








}
