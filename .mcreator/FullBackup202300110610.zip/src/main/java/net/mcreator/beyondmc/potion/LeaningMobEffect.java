
package net.mcreator.beyondmc.potion;

public class LeaningMobEffect extends MobEffect {

	public LeaningMobEffect() {
		super(MobEffectCategory.HARMFUL, -65281);
	}

	@Override public String getDescriptionId() {
		return "effect.beyondmc.leaning";
	}


		@Override public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
    LeaningEffectStartedappliedProcedure.execute(
    entity.level,entity.getX(),entity.getY(),entity.getZ(),entity
);
		}

	@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
    LeaningOnEffectActiveTickProcedure.execute(
    entity.level,entity.getX(),entity.getY(),entity.getZ()
);
	}

	@Override public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
   		super.removeAttributeModifiers(entity, attributeMap, amplifier);
    LeaningEffectExpiresProcedure.execute(
    entity
);
	}

	@Override public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}

}
