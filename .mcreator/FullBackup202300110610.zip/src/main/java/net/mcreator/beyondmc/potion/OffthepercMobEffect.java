
package net.mcreator.beyondmc.potion;

public class OffthepercMobEffect extends MobEffect {

	public OffthepercMobEffect() {
		super(MobEffectCategory.HARMFUL, -3355444);
	}

	@Override public String getDescriptionId() {
		return "effect.beyondmc.offtheperc";
	}


		@Override public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
    OffthepercEffectStartedappliedProcedure.execute(
    entity.level,entity
);
		}


	@Override public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
   		super.removeAttributeModifiers(entity, attributeMap, amplifier);
    OffthepercEffectExpiresProcedure.execute(
    entity
);
	}

	@Override public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}

}
