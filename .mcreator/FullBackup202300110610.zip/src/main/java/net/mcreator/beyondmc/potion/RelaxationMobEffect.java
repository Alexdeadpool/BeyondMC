
package net.mcreator.beyondmc.potion;

public class RelaxationMobEffect extends MobEffect {

	public RelaxationMobEffect() {
		super(MobEffectCategory.HARMFUL, -10027162);
	}

	@Override public String getDescriptionId() {
		return "effect.beyondmc.relaxation";
	}


		@Override public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
    RelaxationEffectStartedappliedProcedure.execute(
    entity.level,entity.getX(),entity.getY(),entity.getZ(),entity
);
		}

	@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
    RelaxationOnEffectActiveTickProcedure.execute(
    entity.level,entity.getX(),entity.getY(),entity.getZ()
);
	}

	@Override public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
   		super.removeAttributeModifiers(entity, attributeMap, amplifier);
    RelaxationEffectExpiresProcedure.execute(
    entity
);
	}

	@Override public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}

}
