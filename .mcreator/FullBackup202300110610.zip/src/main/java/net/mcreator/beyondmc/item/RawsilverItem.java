

package net.mcreator.beyondmc.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class RawsilverItem extends Item {

	public RawsilverItem() {
		super(new Item.Properties()
				.tab(CreativeModeTab.TAB_MISC)
				.stacksTo(64)
				.rarity(Rarity.COMMON)
		);
	}



















}
